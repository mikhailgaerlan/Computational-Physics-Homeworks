<script type="text/javascript" src="http://latex.codecogs.com/latexit.js"></script>
<script type="text/javascript">
LatexIT.add('p',true);
</script>
#PH 4433/6433 Homework 3

Mikhail Gaerlan  
16 September 2015

##[Home](hw3.html)

---

1. [Knife-edge Diffraction](1/hw3-1.html)
2. [Differentiation](2/hw3-2.html)
3. [Plane pendulum](3/hw3-3.html)
