#PH 4433/6433 Homework 1

Mikhail Gaerlan  
26 August 2015

##[Home](hw1.html)

---

1. [Problem 1](1/hw1-1.html)
2. [Problem 2](2/hw1-2.html)
3. [Problem 3](3/hw1-3.html)
4. [Problem 4](4/hw1-4.html)
