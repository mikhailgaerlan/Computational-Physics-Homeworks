<script type="text/javascript" src="http://latex.codecogs.com/latexit.js"></script>
<script type="text/javascript">
LatexIT.add('p',true);
</script>
#PH 4433/6433 Homework 7

Mikhail Gaerlan  
28 October 2015

##[Home](hw7.html)

---

1. [Linear least-squares fit](1/hw7-1.html)
2. [Fitting an ellipse](2/hw7-2.html)
