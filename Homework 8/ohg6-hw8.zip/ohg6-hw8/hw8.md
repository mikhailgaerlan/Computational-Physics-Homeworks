<script type="text/javascript" src="http://latex.codecogs.com/latexit.js"></script>
<script type="text/javascript">
LatexIT.add('p',true);
</script>
#PH 4433/6433 Homework 

Mikhail Gaerlan  
9 November 2015

##[Home](hw8.html)

---

1. [10-dimensional integral](1/hw8-1.html)
2. [Metropolis](2/hw8-2.html)
