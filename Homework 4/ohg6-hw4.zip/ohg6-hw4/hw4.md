<script type="text/javascript" src="http://latex.codecogs.com/latexit.js"></script>
<script type="text/javascript">
LatexIT.add('p',true);
</script>
#PH 4433/6433 Homework 4

Mikhail Gaerlan  
30 September 2015

##[Home](hw4.html)

---

1. [ODE Solvers](1/hw4-1.html)
2. [Classical Scattering](2/hw4-2.html)
